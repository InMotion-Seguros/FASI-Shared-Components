﻿Namespace Exceptions

    ''' <summary>
    ''' SecurityException class. // Clase SecurityException.
    ''' </summary>
    Public Class SecurityException
        Inherits InMotionGIT.Common.Exceptions.InMotionGITException

    End Class

End Namespace