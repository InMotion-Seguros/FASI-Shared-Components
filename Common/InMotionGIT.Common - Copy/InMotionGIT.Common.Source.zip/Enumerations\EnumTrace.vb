﻿Namespace Enumerations

    Public Enum EnumTraceType
        [Error] = 0
        Trace = 1
        Warrning = 2
        Audit = 4
        Other = 3
    End Enum

End Namespace