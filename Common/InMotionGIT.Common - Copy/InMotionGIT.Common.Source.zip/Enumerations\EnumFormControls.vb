﻿Namespace Enumerations

    Public Enum EnumFormControls
        None
        Time
    End Enum

End Namespace