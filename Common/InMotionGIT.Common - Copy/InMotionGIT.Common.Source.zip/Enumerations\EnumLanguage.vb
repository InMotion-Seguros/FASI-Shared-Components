﻿Namespace Enumerations

    Public Enum EnumLanguage
        None = 0
        English = 1
        Spanish = 2
        Portuguese = 3
        Dutch = 4
    End Enum

End Namespace