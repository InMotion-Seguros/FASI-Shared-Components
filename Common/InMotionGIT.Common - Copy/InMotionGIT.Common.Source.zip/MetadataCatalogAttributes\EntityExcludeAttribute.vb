﻿Namespace Attributes

    ''' <summary>
    '''
    ''' </summary>
    ''' <remarks></remarks>
    <AttributeUsage(AttributeTargets.Class)>
    Public NotInheritable Class EntityExcludeAttribute
        Inherits Attribute

        Public Sub New()
            MyBase.New()
        End Sub

    End Class

End Namespace