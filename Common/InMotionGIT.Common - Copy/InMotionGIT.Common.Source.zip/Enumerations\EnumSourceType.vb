﻿Namespace Enumerations

    Public Enum EnumSourceType
        Oracle = 0
        SqlServer = 1
        ErwinXML
        Postgres
    End Enum

End Namespace