﻿Namespace DataAccess.WhereStatements

    Public Interface IWhereStatement

        Property command As String

    End Interface

End Namespace