﻿Namespace Enumerations

    Public Enum EnumApplicationVersion
        None = 0
        USALife = 1
        LatCombined = 2

        'Custom_Argentina
        'Custom_CanadaLife
        'Custom_TheEdge
    End Enum

End Namespace