﻿Namespace Enumerations

    Public Enum EnumNotifySeverity
        [Error]
        Warning
        Message
    End Enum

End Namespace