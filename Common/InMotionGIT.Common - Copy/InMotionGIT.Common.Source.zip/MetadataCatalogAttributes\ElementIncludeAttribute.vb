﻿Namespace Attributes

    <AttributeUsage(AttributeTargets.Property)>
    Public NotInheritable Class ElementIncludeAttribute
        Inherits Attribute

    End Class

End Namespace