﻿Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Common.Proxy")>
<Assembly: AssemblyDescription("Proxy para acceso a datos genérico.")>
<Assembly: AssemblyCompany("InMotionGIT")>
<Assembly: AssemblyProduct("FASI")>
<Assembly: AssemblyCopyright("Copyright © InMotionGIT 2011")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("255ca358-19bf-4784-a427-a8c5c6d5e7a2")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>